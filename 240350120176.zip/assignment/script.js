document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
  
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
  
    let valid = true;
  
    if (!validateEmail(username)) {
      document.getElementById('usernameError').innerText = 'Please enter a valid email.';
      document.getElementById('usernameError').style.display = 'block';
      valid = false;
    } else {
      document.getElementById('usernameError').style.display = 'none';
    }
  
    if (password.length < 6) {
      document.getElementById('passwordError').innerText = 'Password must be at least 6 characters long.';
      document.getElementById('passwordError').style.display = 'block';
      valid = false;
    } else {
      document.getElementById('passwordError').style.display = 'none';
    }
  
    if (valid) {
      login(username, password);
    }
  });
  
  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
  }
  
  function login(username, password) {
    fetch('https://jsonplaceholder.typicode.com/posts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ username, password })
    })
      .then(response => response.json())
      .then(data => {
        document.getElementById('message').innerText = 'Login successful!';
      })
      .catch(error => {
        document.getElementById('message').innerText = 'Login failed!';
      });
  }
  